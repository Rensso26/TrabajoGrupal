package uce.grupal.history;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HistoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
